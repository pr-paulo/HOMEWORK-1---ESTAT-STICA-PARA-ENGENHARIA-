library(openxlsx)
library(DescTools)

setwd("/Users/isadoracarneiro/Documents/Paulo Roberto/HOMEWORK")
# Encontra o arquivo original enviado pela professora no computador.

# PRIMEIRA QUESTÃO:

arquivo_original <- read.csv("HW1_bike_sharing.csv")
# Carrega o arquivo original nO objeto arquivo_original.

M <- 583160
# A maior matrícula do grupo é a do Paulo Muniz (583160).

r <- 1 + (M %% 100)
# Calculo da variável r.

data_group <- arquivo_original[r:(r + 299), ]
# Salva a amostra de 300 elementos selecionadas no objeto data_group.

# SEGUNDA QUESTÃO:

data_group$total_user <- data_group$casual + data_group$registered
# Cria a variável total_user, que soma os valores das colunas casual e registered.

write.xlsx(data_group, "HW1_data_group.xlsx")

# Calculo da média, mediana e moda das primeiras 10 amostras [1,10].

# temp
temp_media10   <- mean(data_group$temp[1:10])
temp_mediana10 <- median(data_group$temp[1:10])
temp_moda10    <- Mode(data_group$temp[1:10])[1]

# casual
casual_media10   <- mean(data_group$casual[1:10])
casual_mediana10 <- median(data_group$casual[1:10])
casual_moda10    <- Mode(data_group$casual[1:10])[1]

# registered
registered_media10   <- mean(data_group$registered[1:10])
registered_mediana10 <- median(data_group$registered[1:10])
registered_moda10    <- Mode(data_group$registered[1:10])[1]

# total_user
total_user_media10   <- mean(data_group$total_user[1:10])
total_user_mediana10 <- median(data_group$total_user[1:10])
total_user_moda10    <- Mode(data_group$total_user[1:10])[1]

tabela_para_10_amostras <- data.frame(
  Variavel = c("temp", "casual", "registered", "total_user"),
  Media = c(temp_media10, casual_media10, registered_media10, total_user_media10),
  Mediana = c(temp_mediana10, casual_mediana10, registered_mediana10, total_user_mediana10),
  Moda = c(temp_moda10, casual_moda10, registered_moda10, total_user_moda10)
)

# Calculo da média, mediana e moda de todas as amostras.

# temp
temp_media   <- mean(data_group$temp)
temp_mediana <- median(data_group$temp)
temp_moda    <- Mode(data_group$temp)[1]

# casual
casual_media   <- mean(data_group$casual)
casual_mediana <- median(data_group$casual)
casual_moda   <- Mode(data_group$casual)[1]

# registered
registered_media   <- mean(data_group$registered)
registered_mediana <- median(data_group$registered)
registered_moda    <- Mode(data_group$registered)[1]

# total_user
total_user_media   <- mean(data_group$total_user)
total_user_mediana <- median(data_group$total_user)
total_user_moda    <- Mode(data_group$total_user)[1]

tabela_para_todas_as_amostras <- data.frame(
  Variavel = c("temp", "casual", "registered", "total_user"),
  Media = c(temp_media, casual_media, registered_media, total_user_media),
  Mediana = c(temp_mediana, casual_mediana, registered_mediana, total_user_mediana),
  Moda = c(temp_moda, casual_moda, registered_moda, total_user_moda)
)

# Calculo dos quartis (Q1,Q2 e Q3) e do intervalo interquartil para 10 amostras [1,10].
# A variável numérica relevante escolhida foi total_user.

# Calculo dos quartis para 10 amostras.
total_user_Q1_10 <- quantile(data_group$total_user[1:10], 0.25) # 1º Quartil (25%)
total_user_Q2_10 <- quantile(data_group$total_user[1:10], 0.50) # 2º Quartil (Mediana - 50%)
total_user_Q3_10 <- quantile(data_group$total_user[1:10], 0.75) # 3º Quartil (75%)

# Intervalo Interquartil para 10 amostras.
total_user_IQR_10 <- IQR(data_group$total_user[1:10])

tabela_dos_quartis_para_10_amostras <- data.frame(
  Medida = c("Q1 (25%)", "Q2 (Mediana - 50%)", "Q3 (75%)", "IQR"),
  Valor = c(total_user_Q1_10, total_user_Q2_10, total_user_Q3_10, total_user_IQR_10)
)

# Calculo dos Outliners para as 10 amostras.

limite_inferior_10 <- total_user_Q1_10 - 1.5 * total_user_IQR_10
limite_superior_10 <- total_user_Q3_10 + 1.5 * total_user_IQR_10

outliers_para_as_10 <- data_group[1:10,][data_group$total_user[1:10] < limite_inferior_10 | data_group$total_user[1:10] > limite_superior_10, ]

tabela_dos_bigodes_para_10 <- data.frame(
  Medida = c("Limite Inferior", "Limite Superior"),
  Valor = c(limite_inferior_10, limite_superior_10)
)

# Calculo dos quartis (Q1,Q2 e Q3) e do intervalo interquartil para todas as amostras.

# Calculo dos quartis para todas as amostras.
total_user_Q1 <- quantile(data_group$total_user, 0.25) 
total_user_Q2 <- quantile(data_group$total_user, 0.50)
total_user_Q3 <- quantile(data_group$total_user, 0.75) 

# Intervalo Interquartil para todas as amostras.
total_user_IQR <- IQR(data_group$total_user)

tabela_dos_quartis_para_todas_as_amostras <- data.frame(
  Medida = c("Q1 (25%)", "Q2 (Mediana - 50%)", "Q3 (75%)", "IQR"),
  Valor = c(total_user_Q1, total_user_Q2, total_user_Q3, total_user_IQR)
)

# Calculo dos Outliers para todas as amostras.

limite_inferior <- total_user_Q1 - 1.5 * total_user_IQR
limite_superior <- total_user_Q3 + 1.5 * total_user_IQR

outliers_para_todas_as_amostras <- data_group[data_group$total_user < limite_inferior | data_group$total_user > limite_superior, ]

tabela_dos_bigodes <- data.frame(
  Medida = c("Limite Inferior", "Limite Superior"),
  Valor = c(limite_inferior, limite_superior)
)

# Histograma do total_user: 

hist(data_group$total_user,
     main = "Histograma do Total_User",
     xlab = "Total de Usuários",
     ylab = "Frequência Absoluta",
     col = "blue",
     border = "white",
     xlim = c(0, 7000))

# Boxplot do total_user:

boxplot(data_group$total_user,
        main = "Boxplot do Total_User",
        ylab = "Total de Usuários",
        col = "red",
        outline = TRUE,
        ylim = c(0, 7000))

# Tópico 5 da questão 2:

data_group$low_usage <- ifelse(data_group$total_user < total_user_Q1, 1, 0) # Vereifica se o dia o dia foi um dia de baixa utilização e salva em low_usage.

qtd_dias_baixa <- sum(data_group$low_usage == 1) # Quantidade de dias de baixa utilização.
proporcao_baixa <- sum(data_group$low_usage) / nrow(data_group) # Proporção desses dias, que é a soma dos dias de baixa utilização pelo total de dias.

tabela_item_5 <- data.frame(
  Métrica = c("Q1", "Quantidade de dias de baixa utilização", "Proporção de dias de baixa utilização"),
  Valor = c(total_user_Q1, qtd_dias_baixa, proporcao_baixa)
)

# TERCEIRA QUESTÃO:  

# PARTE 1:
data_group_3_1 <- data_group[, c("season", "total_user", "low_usage")] # Cria um data_set só com as variáveis season, total_user e low_usage.

# Calculo do desvio padrão para as primeiras 10 amostras da primavera:

dados_primavera_10 <- subset(data_group, season == 1)[1:10, ]

desvio_padrao_primavera_10 <- sd(dados_primavera_10$total_user)

tabela_3_1_primavera_10 <- data.frame(
  Estacao = "Primavera (1)",
  Amostras = "1 a 10",
  Desvio_Padrao = desvio_padrao_primavera_10
)

write.xlsx(tabela_3_1_primavera_10, file = "tabela_3_1_primavera_10.xlsx")

# Primavera (1):

dados_primavera <- subset(data_group_3_1, season == 1) # Pegando só os dias que que são primavera. 

# Calculo da média, mediana, desvio padrão e da proporção:
media_primavera         <- mean(dados_primavera$total_user)
mediana_primavera       <- median(dados_primavera$total_user)
desvio_padrao_primavera <- sd(dados_primavera$total_user)
proporcao_primavera     <- mean(dados_primavera$low_usage)

# Verão (2):

dados_verao <- subset(data_group_3_1, season == 2) # Pegando só os dias que que são verão. 

# Calculo da média, mediana, desvio padrão e da proporção:
media_verao         <- mean(dados_verao$total_user)
mediana_verao       <- median(dados_verao$total_user)
desvio_padrao_verao <- sd(dados_verao$total_user)
proporcao_verao     <- mean(dados_verao$low_usage)

# Outono (3):

dados_outono <- subset(data_group_3_1, season == 3) # Pegando só os dias que que são Outono. 

# Calculo da média, mediana, desvio padrão e da proporção:
media_outono         <- mean(dados_outono$total_user)
mediana_outono       <- median(dados_outono$total_user)
desvio_padrao_outono <- sd(dados_outono$total_user)
proporcao_outono     <- mean(dados_outono$low_usage)

# Verão (4):

dados_inverno <- subset(data_group_3_1, season == 4) # Pegando só os dias que que são inverno. 

# Calculo da média, mediana, desvio padrão e da proporção:
media_inverno         <- mean(dados_inverno$total_user)
mediana_inverno       <- median(dados_inverno$total_user)
desvio_padrao_inverno <- sd(dados_inverno$total_user)
proporcao_inverno     <- mean(dados_inverno$low_usage)

tabela_3_1 <- data.frame(
  Estacao = c("Primavera (1)", "Verão (2)", "Outono (3)", "Inverno (4)"),
  Media = c(media_primavera, media_verao, media_outono, media_inverno),
  Mediana = c(mediana_primavera, mediana_verao, mediana_outono, mediana_inverno),
  Desvio_Padrao = c(desvio_padrao_primavera, desvio_padrao_verao, desvio_padrao_outono, desvio_padrao_inverno),
  Proporcao_low_usage = c(proporcao_primavera, proporcao_verao, proporcao_outono, proporcao_inverno)
)

data_group_3_1$estacao_fator <- factor(data_group_3_1$season, levels = c(1, 2, 3, 4), labels = c("Primavera (1)", "Verão (2)", "Outono (3)", "Inverno (4)")) # Previni erro quando for plotar o boxplot, pois é possível que no nosso dataset não tenha todas as seasons.

boxplot(total_user ~ estacao_fator, 
        data = data_group_3_1,
        main = "Boxplots das Seasons",
        xlab = "Estação do Ano",
        ylab = "Total de Usuários",
        col = c("orange", "yellow", "lightblue", "blue"),
        drop = FALSE)

# PARTE 2:
data_group_3_2 <- data_group[, c("weathersit", "total_user", "low_usage")] # Cria um data_set só com as variáveis weathersit, total_user e low_usage.

# Céu limpo (1):

dados_limpo <- subset(data_group_3_2, weathersit == 1) # Pegando só os dias com céu limpo. 

# Calculo da média, desvio padrão e da proporção:
media_limpo          <- mean(dados_limpo$total_user)
desvio_padrao_limpo  <- sd(dados_limpo$total_user)
proporcao_limpo      <- mean(dados_limpo$low_usage)

# Nublado (2):

dados_nublado <- subset(data_group_3_2, weathersit == 2) # Pegando só os dias nublados. 

# Calculo da média, desvio padrão e da proporção:
media_nublado          <- mean(dados_nublado$total_user)
desvio_padrao_nublado  <- sd(dados_nublado$total_user)
proporcao_nublado      <- mean(dados_nublado$low_usage)

# Chuva fraca (3):

dados_chuva_fraca <- subset(data_group_3_2, weathersit == 3) # Pegando só os dias de chuva fraca. 

# Calculo da média, desvio padrão e da proporção:
media_chuva_fraca          <- mean(dados_chuva_fraca$total_user)
desvio_padrao_chuva_fraca  <- sd(dados_chuva_fraca$total_user)
proporcao_chuva_fraca      <- mean(dados_chuva_fraca$low_usage)

# Chuva forte (4):

dados_chuva_forte <- subset(data_group_3_2, weathersit == 4) # Pegando só os dias de chuva forte. 

# Calculo da média, desvio padrão e da proporção:
media_chuva_forte          <- mean(dados_chuva_forte$total_user)
desvio_padrao_chuva_forte  <- sd(dados_chuva_forte$total_user)
proporcao_chuva_forte      <- mean(dados_chuva_forte$low_usage)

tabela_3_2 <- data.frame(
  Clima = c("Céu limpo (1)", "Nublado (2)", "Chuva fraca (3)", "Chuva forte (4)"),
  Media = c(media_limpo, media_nublado, media_chuva_fraca, media_chuva_forte),
  Desvio_Padrao = c(desvio_padrao_limpo, desvio_padrao_nublado, desvio_padrao_chuva_fraca, desvio_padrao_chuva_forte),
  Proporcao_low_usage = c(proporcao_limpo, proporcao_nublado, proporcao_chuva_fraca, proporcao_chuva_forte)
)

write.xlsx(tabela_3_2, file = "tabela_3_2.xlsx")

data_group_3_2$clima_fator <- factor(data_group_3_2$weathersit, levels = c(1, 2, 3, 4), labels = c("Céu limpo (1)", "Nublado (2)", "Chuva fraca (3)", "Chuva forte (4)"))  # Previni erro quando for plotar o boxplot, pois é possível que no nosso dataset não tenha todas as weathersits. 

boxplot(total_user ~ clima_fator, 
        data = data_group_3_2,
        main = "Boxplots das Weathersits",
        xlab = "Condição Meteorológica",
        ylab = "Total de Usuários",
        col = c("lightskyblue", "lightgray", "steelblue", "darkblue"),
        drop = FALSE)

# PARTE 3:

# Para as 10 primeiras amostras:

plot(data_group$temp[1:10], data_group$total_user[1:10],
     main = "Temperatura vs Total de Usuários (10 Primeiras Amostras)",
     xlab = "temp",
     ylab = "total_user",
     pch = 19,               
     col = "blue",      
     frame.plot = TRUE)

abline(lm(data_group$total_user[1:10] ~ data_group$temp[1:10]), col = "red", lwd = 2)

cor_temp_user_10 <- cor(data_group$temp[1:10], data_group$total_user[1:10], use = "complete.obs") # Calcula o coeficiente de correlação para as 10 primeiras amostras.

tabela_3_3_10 <- data.frame(
  Amostras = "1 a 10",
  Variaveis = "temp vs total_user",
  Correlacao_Pearson = cor_temp_user_10)

write.xlsx(tabela_3_3_10, file = "tabela_3_3_10.xlsx")

# Para todas as amostras: 

plot(data_group$temp, data_group$total_user,
     main = "Temperatura vs Total de Usuários",
     xlab = "temp",
     ylab = "total_user",
     pch = 19,               
     col = "blue",      
     frame.plot = TRUE)

abline(lm(total_user ~ temp, data = data_group), col = "red", lwd = 2)

cor_temp_user <- cor(data_group$temp, data_group$total_user, use = "complete.obs") # Calcula o coeficiente de correlação.

tabela_3_3 <- data.frame(
  Variaveis = "temp vs total_user",
  Correlacao_Pearson = cor_temp_user)

write.xlsx(tabela_3_3, file = "tabela_3_3.xlsx")

# QUARTA QUESTÃO:

# ITEM A

data_group$dteday <- as.Date(data_group$dteday, format = "%Y-%m-%d") 

# Gráfico da Série Temporal
plot(data_group$dteday, data_group$total_user, type = "l", col = "grey", lwd = 2,
     main = "Série Temporal do Uso do Sistema (02/03/2011 a 26/12/2011)",
     xlab = "Data", ylab = "Total de Usuários")

abline(h = 3116.5, col = "red", lty = 2, lwd = 1)   # Estamos utilizando o valor do primeiro quartil, que já foi calculated anteriormente, para mostrar os períodos de baixa utilização.  
abline(h = 4681.0, col = "green", lty = 2, lwd = 1)  # Estamos utilizando o valor do terceiro quartil, que já foi calculated anteriormente, para mostrar os períodos de alta utilização.  

legend("topleft", 
       legend = c("total_user", "Q3 - Alto Uso", "Q1 - Baixo Uso"), 
       col = c("grey", "green", "red"), 
       lty = c(1, 2, 2), 
       lwd = c(2, 1, 1),
       cex = 0.6)  

# ITEM B

# As características selecionadas no item 4 da terceira questão foram temp e season.
# Como já foram plotados anteriormente os gráficos que relacionam essas duas variáveis com a variável total_user, reutilizamo-os na questão.

# Cálculo que demonstra a força da associação entre a variável season e a variável total_user.

modelo_anova_season <- aov(total_user ~ estacao_fator, data = data_group_3_1) # A função aov calcula o quanto dos dados varia entre as estações em comparação com o quanto varia dentro de cada estação.
summary_anova_season <- summary(modelo_anova_season)

# Extração da Soma dos Quadrados
quadrado_grupo_season <- summary_anova_season[[1]]["estacao_fator", "Sum Sq"]
quadrado_residuos_season <- summary_anova_season[[1]]["Residuals", "Sum Sq"]
quadrado_total_season <- quadrado_grupo_season + quadrado_residuos_season

# Cálculo do Eta-Quadrado (η²)
eta_quadrado_season <- quadrado_grupo_season / quadrado_total_season

tabela_4_2_season <- data.frame(
  Caracteristica = "Estação do Ano (season)",
  Medida_Estatistica = "Eta-Quadrado (η²)",
  Valor = eta_quadrado_season
)

# Relação entre a variável temp e a total_user por meio do coeficiente de correlação de Pearson.

correlacao_temp <- cor(data_group$temp, data_group$total_user, use = "complete.obs")

tabela_4_2_temp <- data.frame(
  Caracteristica = "Temperatura (temp)",
  Medida_Estatistica = "Correlação de Pearson (r)",
  Valor = correlacao_temp
)

tabela_4_2 <- rbind(tabela_4_2_season, tabela_4_2_temp)

write.xlsx(tabela_4_2, file = "tabela_4_2.xlsx")

# ITEM C

cores <- ifelse(data_group$low_usage == 1, "red", "green") # O ponto que for low_usage fica vermelhor e o que não for fica verde.

plot(data_group$temp, data_group$total_user,
     col = cores, pch = 19,
     main = "Temperatura vs Total de Usuários",
     xlab = "temp", ylab = "total_user")

abline(lm(total_user ~ temp, data = data_group), col = "black", lwd = 2) # Utiliza a mesma reta de tendência global da Questão 3.

legend("topleft", 
       legend = c("low_usage = 0", "low_usage = 1"),
       col = c("green", "red"), pch = 19, cex = 0.6)